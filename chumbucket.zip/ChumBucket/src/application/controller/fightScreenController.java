package application.controller;
import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;


public class fightScreenController {
	
	/*
	 * fxml variables and class variables
	 * go here
	 */
	
	public void handle(ActionEvent event) {
		
	}
	
}
